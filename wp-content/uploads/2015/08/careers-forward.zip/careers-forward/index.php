<?php get_header(); ?>

HELLOOOOOO

<?php get_footer(); ?>
