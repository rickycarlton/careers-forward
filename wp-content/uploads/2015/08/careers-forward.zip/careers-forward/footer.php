

<script type="text/javascript" src="/wp-content/themes/patsos/js/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="/wp-content/themes/patsos/js/init.js"></script>

<?php wp_footer(); ?>

</body>
</html>
